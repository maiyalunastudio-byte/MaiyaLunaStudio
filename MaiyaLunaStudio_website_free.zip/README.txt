# MaiyaLunaStudio — Free Website Starter

This is a simple one-page website you can host for free.

Files:
- index.html — the complete website
- maiyaluna-logo.png — your MaiyaLunaStudio brand image

Free hosting options include GitHub Pages, Netlify, and Cloudflare Pages.

Next, we can customize the site with your real photos, bio, social links, services/products, and Hmong-inspired design details.
